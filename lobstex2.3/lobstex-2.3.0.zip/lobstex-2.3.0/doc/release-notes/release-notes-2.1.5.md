v2.1.5

1. Rpi wallet now has Static Qt binary!
2. autocombinerewards feature - Automatically combines masternode reward once spendable into a single input.
3. Network enhancements - Increase outbound connections.
4. BIP38 tool now supports more characters.
5. Icons changed to non-transparent icon for better visibility.
6. Multisend now can filter between staking and masternode rewards (soon). Also some bugs addressed.
7. Wallet crashing with certain blockchain corruption has been prevented.
8. Lots of updates for OS X build.
9. In-Wallet Blockexplorer! (still needs Styling)
10. Added Fallback Seed Nodes - You no longer need to add initial addnodes lines to lobstex.conf!
11. Lots more minor updates (readme, copyright etc) and bug fixes.
